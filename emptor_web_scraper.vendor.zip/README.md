# Emptor's Web Scraper Challenge

The project is aimed towards creating a web scraper application with a serverless framework. It incorporates use of aws lambda and dynamo db.

Input: url
Output: title of the web page
